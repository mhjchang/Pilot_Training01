#ifdef __cplusplus
extern "C"{
#endif

#include "lmic/lmic.h"

#ifdef __cplusplus
}
#endif
