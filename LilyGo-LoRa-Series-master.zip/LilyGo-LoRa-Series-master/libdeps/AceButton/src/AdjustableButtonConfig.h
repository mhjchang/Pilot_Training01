/*
 * This file has moved to <ace_button/AdjustableButtonConfig.h> and is
 * deprecated as of version 1.1. The <AceButton.h> header automatically includes
 * <ace_button/AdjustableButtonConfig.h>. You can remove the line in your code
 * that does:
 *
 *  #include <AdjustableButtonConfig.h>
 *
 * You only need to do:
 *
 *  #include <AceButton.h>
 */
