#pragma once




void setupLMIC(void);
void loopLMIC(void);


